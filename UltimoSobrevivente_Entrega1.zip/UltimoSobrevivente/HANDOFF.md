# HANDOFF — Último Sobrevivente, Primeira Entrega

## Pedido
Primeira Entrega do briefing (CLAUDE.md): projeto UE5 Android, C++, personagem 3ª pessoa, câmera, movimentação, touch, mapa explorável, 1 inimigo com IA, combate básico, vida e dano.

## Medido neste ambiente
Sem Unreal Engine, sem Android SDK/NDK, sem rede. Só g++ genérico, python3, zip. Nada do projeto foi compilado.

## Suposições (não verificadas)
- Engine 5.5 (`EngineAssociation`). Chaves de `Config/*.ini` (AndroidRuntimeSettings, RecastNavMesh RuntimeGeneration) escritas de memória.
- `/Engine/BasicShapes/Cube|Cylinder` existem; parâmetro de cor `Color` do material básico.
- `BindAxisKey`/`BindKey` funcionam com o EnhancedInputComponent padrão da UE5.

## Arquivos
Ver `Docs/ARQUITETURA.md`.

## Próximo passo verificável
Gerar projeto VS, compilar `UltimoSobreviventeEditor`, corrigir erros de compilação reais, criar `L_CidadeMorta` + NavMeshBoundsVolume, dar Play no PC.
