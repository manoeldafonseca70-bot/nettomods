# Primeiros passos

> Nada neste projeto foi compilado nem executado ainda. Estes passos são o roteiro para a primeira compilação.

## 1. Versão da engine
O `.uproject` aponta para `"EngineAssociation": "5.5"` (escolha minha, não verificada contra a sua instalação).
Se usa outra 5.x: clique direito em `UltimoSobrevivente.uproject` → *Switch Unreal Engine version*.
O código usa só APIs de UE 5.1+ (por ex. `GetSkeletalMeshAsset()`); `Build.cs` e `*.Target.cs` usam `BuildSettingsVersion.V5` e `EngineIncludeOrderVersion.Latest`.

## 2. Compilar
1. Instale Visual Studio com o workload C++ para jogos (versão exigida pela sua versão da UE).
2. Clique direito no `.uproject` → *Generate Visual Studio project files*.
3. Compile `UltimoSobreviventeEditor` (Development Editor, Win64) e abra o projeto.
4. Envie os erros de compilação, se houver; eles devem ser corrigidos antes de qualquer outra etapa.

## 3. Criar o mapa (um .umap é binário, não dá para gerar por texto)
1. *File → New Level → Empty Level*. Salve como `Content/Mapas/L_CidadeMorta`.
2. Arraste um **NavMeshBoundsVolume** para o nível e escale para cobrir ~ 20000 × 20000 × 1000 cm, centrado na origem.
3. Nenhum outro ator é necessário: o `AUSGameMode` cria o distrito, o PlayerStart e os infectados ao iniciar.
   (Para ver o distrito no editor, arraste `AUSProceduralDistrict` para o nível.)

## 4. Testar no PC
*Play*. Controles: WASD, mouse, Shift (correr), Espaço, C (agachar), botão esquerdo (atacar), botão direito (mirar), R, Q (trocar arma).
Para ver os controles touch no PC: execute com o argumento `-ForceTouch` e `bUseMouseForTouch` ligado em Project Settings → Input.

## 5. Personagem 3D e animação
O corpo provisório some sozinho quando o Mesh recebe uma `USkeletalMesh`.
1. *Content Browser → Add → Add Feature or Content Pack → Third Person* (traz os manequins e animações da própria Epic).
2. Crie um Blueprint filho de `AUSCharacter` (`BP_Jogador`): defina o Mesh (esqueleto do manequim), a rotação (Z -90, posição Z -88) e a *Anim Class*.
3. Para a Anim Class, crie um Animation Blueprint com Parent Class `UUSAnimInstance` e ligue a state machine às variáveis (`Speed`, `Direction`, `bIsFalling`, `bIsCrouching`, `bIsAiming`).
4. Crie `BP_GameMode` filho de `AUSGameMode` e aponte o Default Pawn para `BP_Jogador`. Repita para o infectado (`BP_Infectado`, filho de `AUSInfectedCharacter`) e ajuste `InfectedClass` no GameMode.

## 6. Android
1. Rode o `SetupAndroid` que acompanha a sua versão da engine (em `Engine/Extras/Android`) ou configure *Project Settings → Platforms → Android SDK*; confirme as versões de JDK/NDK/SDK exigidas pela *sua* versão da UE na documentação oficial.
2. *Project Settings → Platforms → Android*: confira Package Name, orientação e que Vulkan está ligado.
3. *Platforms → Android → Package Project* (ou Launch no aparelho conectado). Gerar APK/AAB exige tudo acima instalado.
