# Arquitetura — Primeira Entrega

Módulo único `UltimoSobrevivente` (C++). Includes partem da raiz do módulo, ex.: `#include "Personagens/USCharacter.h"`.

| Pasta | Classe | Função |
|---|---|---|
| `Personagens/` | `AUSCharacter` | Jogador: câmera (SpringArm), movimentação, mira, entrada (teclado + API touch), morte |
| `Personagens/` | `USPlaceholderBody.h` | Corpo provisório (cilindro + nariz) até existir malha esquelética |
| `Animacoes/` | `UUSAnimInstance` | Base nativa para um Animation Blueprint (Speed, Direction, IsFalling…) |
| `Sobrevivencia/` | `UUSHealthComponent` | Vida/dano via `OnTakeAnyDamage`; eventos `OnHealthChanged`, `OnDeath` |
| `Armas/` | `UUSWeaponComponent` | Pistola (hitscan) e Facão (varredura de esfera); munição, recarga, recuo, ruído |
| `Inimigos/` | `AUSInfectedCharacter` | Corpo, vida, parâmetros e golpe do Infectado |
| `Inimigos/` | `AUSInfectedAIController` | IA: Patrulha → Investigação → Perseguição → Ataque; visão + audição |
| `Interface/` | `AUSPlayerController` | Touch: joystick flutuante, giro de câmera, 7 botões |
| `Interface/` | `AUSHUD` | Vida, arma/munição, mira, joystick e botões (Canvas) |
| `Mapas/` | `AUSProceduralDistrict` | Primeiro cenário: quarteirão gerado em código (cubos) |
| `Mapas/` | `AUSGameMode` | Classes padrão, cria distrito, povoa infectados, respawn |

## Dependências
`AUSGameMode` → `AUSCharacter`, `AUSPlayerController`, `AUSHUD`, `AUSInfectedCharacter`, `AUSProceduralDistrict`.
`AUSCharacter` → `UUSHealthComponent`, `UUSWeaponComponent`, `AUSGameMode` (aviso de morte).
`AUSInfectedAIController` → `AUSInfectedCharacter`, `AUSCharacter` (só reconhece o jogador como alvo), `UUSHealthComponent`.
Módulos de engine: Core, CoreUObject, Engine, InputCore, AIModule, NavigationSystem, GameplayTasks.

## Fluxo de entrada
Teclado/mouse (`SetupPlayerInputComponent`) e touch (`AUSPlayerController`) chamam a mesma API `Input*` de `AUSCharacter`.

## Fluxo de ruído → IA
`AUSCharacter::UpdateNoise` (passos) e `UUSWeaponComponent` (tiro/golpe) chamam `UAISense_Hearing::ReportNoiseEvent`.
O controlador do infectado reage em `OnTargetPerceptionUpdated`.

## Multiplayer futuro (NÃO implementado)
Preparado apenas em: dano processado só com autoridade (`UUSHealthComponent`), entrada isolada na API `Input*`,
lógica de IA no servidor. **Nada está replicado** (sem `SetReplicates`, sem `UPROPERTY(Replicated)`, sem RPCs).
Replicar inventário, bases e personagens é trabalho das entregas seguintes e precisa de teste com servidor dedicado.

## Limites conhecidos
- Sem malha humana, animações, sons, efeitos, texturas: usa formas básicas da engine.
- Sem escalada, natação, interação com objetos, animações de ferimento/morte.
- Valores numéricos (velocidades, dano, sensibilidade, posição dos botões) são provisórios e não calibrados.
- HUD touch sem tratamento de notch/áreas seguras e sem tela de personalização.
- IA sem Behavior Tree/EQS; sem NavMesh no nível ela anda em linha reta, sem desviar de obstáculos.
