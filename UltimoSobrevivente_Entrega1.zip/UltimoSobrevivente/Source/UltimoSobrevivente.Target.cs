using UnrealBuildTool;

public class UltimoSobreviventeTarget : TargetRules
{
	public UltimoSobreviventeTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
		ExtraModuleNames.Add("UltimoSobrevivente");
	}
}
