using UnrealBuildTool;

public class UltimoSobrevivente : ModuleRules
{
	public UltimoSobrevivente(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageType.UseExplicitOrSharedPCHs;

		// Os includes do projeto usam o caminho a partir da raiz do modulo, ex.: "Personagens/USCharacter.h"
		PublicIncludePaths.Add(ModuleDirectory);

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"InputCore",
			"AIModule",
			"NavigationSystem",
			"GameplayTasks"
		});
	}
}
