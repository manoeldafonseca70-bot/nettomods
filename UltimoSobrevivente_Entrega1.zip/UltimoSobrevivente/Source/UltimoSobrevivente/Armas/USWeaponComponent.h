#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "USWeaponComponent.generated.h"

UENUM(BlueprintType)
enum class EUSWeaponKind : uint8
{
	Ranged UMETA(DisplayName = "Distancia (hitscan)"),
	Melee  UMETA(DisplayName = "Corpo a corpo")
};

/** Parametros de uma arma. TODOS os valores numericos sao provisorios e NAO calibrados em jogo. */
USTRUCT(BlueprintType)
struct FUSWeaponStats
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) FText DisplayName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) EUSWeaponKind Kind = EUSWeaponKind::Ranged;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float Damage = 25.f;
	/** Segundos entre disparos / golpes. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float FireInterval = 0.35f;
	/** Alcance em cm (tiro) ou alcance do golpe em cm (corpo a corpo). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float Range = 6000.f;
	/** Meio-angulo do cone de dispersao, em graus (so tiro). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float SpreadDegrees = 1.0f;
	/** Quanto a mira sobe a cada tiro, em graus. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float RecoilPitchDegrees = 1.5f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bAutomatic = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 MagazineSize = 12;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 StartingReserve = 36;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float ReloadTime = 1.8f;
	/** Raio da esfera varrida no golpe, em cm (so corpo a corpo). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float MeleeRadius = 60.f;
	/** Intensidade e alcance (cm) do ruido que atrai inimigos. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float NoiseLoudness = 1.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float NoiseMaxRange = 3500.f;
};

USTRUCT(BlueprintType)
struct FUSWeaponSlot
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) FUSWeaponStats Stats;
	UPROPERTY(BlueprintReadOnly) int32 Magazine = 0;
	UPROPERTY(BlueprintReadOnly) int32 Reserve = 0;
};

/**
 * Combate do jogador: tiro hitscan a partir da camera, golpe corpo a corpo por varredura de esfera,
 * municao, recarga, recuo e emissao de ruido para a percepcao auditiva da IA.
 * Ainda sem modelo 3D de arma, animacao ou som (dependem de assets que o projeto ainda nao tem).
 */
UCLASS(ClassGroup = (UltimoSobrevivente), meta = (BlueprintSpawnableComponent))
class ULTIMOSOBREVIVENTE_API UUSWeaponComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UUSWeaponComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable, Category = "US|Armas") void StartFire();
	UFUNCTION(BlueprintCallable, Category = "US|Armas") void StopFire();
	UFUNCTION(BlueprintCallable, Category = "US|Armas") void Reload();
	UFUNCTION(BlueprintCallable, Category = "US|Armas") void NextWeapon();

	UFUNCTION(BlueprintPure, Category = "US|Armas") bool IsReloading() const { return bReloading; }
	UFUNCTION(BlueprintPure, Category = "US|Armas") bool IsTriggerHeld() const { return bTriggerHeld; }

	/** Nullptr se nao houver arma. */
	const FUSWeaponSlot* GetCurrentSlot() const { return Slots.IsValidIndex(CurrentIndex) ? &Slots[CurrentIndex] : nullptr; }

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Armas")
	TArray<FUSWeaponSlot> Slots;

protected:
	virtual void BeginPlay() override;

private:
	FUSWeaponSlot* GetMutableSlot() { return Slots.IsValidIndex(CurrentIndex) ? &Slots[CurrentIndex] : nullptr; }

	void TryFire();
	void FireRanged(const FUSWeaponStats& Stats);
	void FireMelee(const FUSWeaponStats& Stats);
	void FinishReload();
	void CancelReload();
	void FaceControlYaw() const;
	void EmitNoise(const FUSWeaponStats& Stats) const;

	int32 CurrentIndex = 0;
	bool bTriggerHeld = false;
	bool bReloading = false;
	float NextFireTime = 0.f;
	FTimerHandle ReloadTimer;
};
