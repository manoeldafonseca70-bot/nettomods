#include "Armas/USWeaponComponent.h"
#include "UltimoSobrevivente.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/Controller.h"
#include "GameFramework/DamageType.h"
#include "Kismet/GameplayStatics.h"
#include "Perception/AISense_Hearing.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "CollisionQueryParams.h"
#include "DrawDebugHelpers.h"

UUSWeaponComponent::UUSWeaponComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false; // so liga enquanto o gatilho esta pressionado

	// Armas iniciais. Valores provisorios, nao calibrados.
	FUSWeaponSlot Pistol;
	Pistol.Stats.DisplayName = FText::FromString(TEXT("Pistola"));
	Pistol.Stats.Kind = EUSWeaponKind::Ranged;
	Pistol.Stats.Damage = 25.f;
	Pistol.Stats.FireInterval = 0.30f;
	Pistol.Stats.Range = 6000.f;
	Pistol.Stats.SpreadDegrees = 0.8f;
	Pistol.Stats.RecoilPitchDegrees = 1.5f;
	Pistol.Stats.MagazineSize = 12;
	Pistol.Stats.StartingReserve = 36;
	Pistol.Stats.ReloadTime = 1.8f;
	Pistol.Stats.NoiseLoudness = 1.f;
	Pistol.Stats.NoiseMaxRange = 3500.f;
	Slots.Add(Pistol);

	FUSWeaponSlot Machete;
	Machete.Stats.DisplayName = FText::FromString(TEXT("Facao"));
	Machete.Stats.Kind = EUSWeaponKind::Melee;
	Machete.Stats.Damage = 40.f;
	Machete.Stats.FireInterval = 0.8f;
	Machete.Stats.Range = 170.f;
	Machete.Stats.MeleeRadius = 70.f;
	Machete.Stats.RecoilPitchDegrees = 0.f;
	Machete.Stats.NoiseLoudness = 0.3f;
	Machete.Stats.NoiseMaxRange = 600.f;
	Slots.Add(Machete);
}

void UUSWeaponComponent::BeginPlay()
{
	Super::BeginPlay();

	for (FUSWeaponSlot& Slot : Slots)
	{
		Slot.Magazine = Slot.Stats.MagazineSize;
		Slot.Reserve = Slot.Stats.StartingReserve;
	}
}

void UUSWeaponComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	const FUSWeaponSlot* Slot = GetCurrentSlot();
	if (bTriggerHeld && Slot && Slot->Stats.bAutomatic)
	{
		TryFire();
	}
}

void UUSWeaponComponent::StartFire()
{
	bTriggerHeld = true;
	SetComponentTickEnabled(true);
	TryFire(); // semi-automatica dispara uma vez por toque; automatica continua no Tick
}

void UUSWeaponComponent::StopFire()
{
	bTriggerHeld = false;
	SetComponentTickEnabled(false);
}

void UUSWeaponComponent::NextWeapon()
{
	if (Slots.Num() < 2)
	{
		return;
	}
	CancelReload();
	CurrentIndex = (CurrentIndex + 1) % Slots.Num();
}

void UUSWeaponComponent::Reload()
{
	FUSWeaponSlot* Slot = GetMutableSlot();
	UWorld* World = GetWorld();
	if (!Slot || !World || bReloading || Slot->Stats.Kind != EUSWeaponKind::Ranged)
	{
		return;
	}
	if (Slot->Magazine >= Slot->Stats.MagazineSize || Slot->Reserve <= 0)
	{
		return;
	}

	bReloading = true;
	World->GetTimerManager().SetTimer(ReloadTimer, this, &UUSWeaponComponent::FinishReload, FMath::Max(0.1f, Slot->Stats.ReloadTime), false);
}

void UUSWeaponComponent::FinishReload()
{
	bReloading = false;
	FUSWeaponSlot* Slot = GetMutableSlot();
	if (!Slot)
	{
		return;
	}
	const int32 Needed = Slot->Stats.MagazineSize - Slot->Magazine;
	const int32 Taken = FMath::Min(Needed, Slot->Reserve);
	Slot->Magazine += Taken;
	Slot->Reserve -= Taken;
}

void UUSWeaponComponent::CancelReload()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(ReloadTimer);
	}
	bReloading = false;
}

void UUSWeaponComponent::TryFire()
{
	FUSWeaponSlot* Slot = GetMutableSlot();
	UWorld* World = GetWorld();
	if (!Slot || !World || bReloading)
	{
		return;
	}

	const float Now = World->GetTimeSeconds();
	if (Now < NextFireTime)
	{
		return;
	}

	if (Slot->Stats.Kind == EUSWeaponKind::Ranged)
	{
		if (Slot->Magazine <= 0)
		{
			Reload(); // pente vazio: tenta recarregar sozinho
			return;
		}
		--Slot->Magazine;
	}

	NextFireTime = Now + FMath::Max(0.05f, Slot->Stats.FireInterval);
	FaceControlYaw();
	EmitNoise(Slot->Stats);

	if (Slot->Stats.Kind == EUSWeaponKind::Ranged)
	{
		FireRanged(Slot->Stats);
	}
	else
	{
		FireMelee(Slot->Stats);
	}
}

void UUSWeaponComponent::FaceControlYaw() const
{
	const APawn* Pawn = Cast<APawn>(GetOwner());
	const AController* Controller = Pawn ? Pawn->GetController() : nullptr;
	if (Controller)
	{
		GetOwner()->SetActorRotation(FRotator(0.f, Controller->GetControlRotation().Yaw, 0.f));
	}
}

void UUSWeaponComponent::EmitNoise(const FUSWeaponStats& Stats) const
{
	if (Stats.NoiseLoudness > 0.f && GetWorld())
	{
		UAISense_Hearing::ReportNoiseEvent(GetWorld(), GetOwner()->GetActorLocation(), Stats.NoiseLoudness, GetOwner(), Stats.NoiseMaxRange, FName(TEXT("Weapon")));
	}
}

void UUSWeaponComponent::FireRanged(const FUSWeaponStats& Stats)
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	AController* Controller = Pawn ? Pawn->GetController() : nullptr;
	UWorld* World = GetWorld();
	if (!Controller || !World)
	{
		return;
	}

	// O tiro sai da camera (mira no centro da tela), padrao em jogos de terceira pessoa.
	FVector ViewLocation;
	FRotator ViewRotation;
	Controller->GetPlayerViewPoint(ViewLocation, ViewRotation);

	const FVector Direction = FMath::VRandCone(ViewRotation.Vector(), FMath::DegreesToRadians(FMath::Max(0.f, Stats.SpreadDegrees)));
	const FVector End = ViewLocation + Direction * Stats.Range;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(US_WeaponTrace), /*bTraceComplex*/ true, GetOwner());
	FHitResult Hit;
	const bool bHit = World->LineTraceSingleByChannel(Hit, ViewLocation, End, ECC_Visibility, Params);

	if (bHit && Hit.GetActor())
	{
		UGameplayStatics::ApplyPointDamage(Hit.GetActor(), Stats.Damage, Direction, Hit, Controller, GetOwner(), UDamageType::StaticClass());
	}

#if ENABLE_DRAW_DEBUG
	// Rastro provisorio ate existir efeito de tiro (Niagara) e modelo de arma.
	DrawDebugLine(World, GetOwner()->GetActorLocation() + FVector(0.f, 0.f, 50.f), bHit ? Hit.ImpactPoint : End, FColor::Yellow, false, 0.08f, 0, 1.5f);
#endif

	// Recuo: sobe a mira. Valor nao calibrado.
	if (Stats.RecoilPitchDegrees > 0.f)
	{
		Controller->SetControlRotation(Controller->GetControlRotation() + FRotator(Stats.RecoilPitchDegrees, 0.f, 0.f));
	}
}

void UUSWeaponComponent::FireMelee(const FUSWeaponStats& Stats)
{
	APawn* Pawn = Cast<APawn>(GetOwner());
	AController* Controller = Pawn ? Pawn->GetController() : nullptr;
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	const FVector Start = GetOwner()->GetActorLocation();
	const FVector Forward = GetOwner()->GetActorForwardVector();
	const FVector End = Start + Forward * Stats.Range;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(US_MeleeSweep), false, GetOwner());
	TArray<FHitResult> Hits;
	World->SweepMultiByChannel(Hits, Start, End, FQuat::Identity, ECC_Pawn, FCollisionShape::MakeSphere(Stats.MeleeRadius), Params);

	TSet<AActor*> AlreadyHit;
	for (const FHitResult& Hit : Hits)
	{
		AActor* Victim = Hit.GetActor();
		if (Victim && !AlreadyHit.Contains(Victim))
		{
			AlreadyHit.Add(Victim);
			UGameplayStatics::ApplyPointDamage(Victim, Stats.Damage, Forward, Hit, Controller, GetOwner(), UDamageType::StaticClass());
		}
	}
}
