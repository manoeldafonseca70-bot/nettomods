#include "UltimoSobrevivente.h"
#include "Modules/ModuleManager.h"

DEFINE_LOG_CATEGORY(LogUS);

IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, UltimoSobrevivente, "UltimoSobrevivente");
