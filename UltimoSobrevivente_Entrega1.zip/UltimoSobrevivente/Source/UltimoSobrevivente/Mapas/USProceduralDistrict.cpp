#include "Mapas/USProceduralDistrict.h"
#include "UltimoSobrevivente.h"

#include "Components/InstancedStaticMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "UObject/ConstructorHelpers.h"

namespace
{
	// Cube da engine: 100 x 100 x 100 cm, pivo no centro.
	constexpr float CubeSizeCm = 100.f;
	// Pontos de rua ficam a, no maximo, esta distancia do eixo da rua (a rua tem >= 800 cm de largura).
	constexpr float StreetHalfSpread = 300.f;
	constexpr float PawnSpawnHeight = 150.f;
}

AUSProceduralDistrict::AUSProceduralDistrict()
{
	PrimaryActorTick.bCanEverTick = false;

	Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);

	Ground = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Ground"));
	Ground->SetupAttachment(Root);
	Ground->SetCollisionProfileName(TEXT("BlockAll"));

	Structures = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("Structures"));
	Structures->SetupAttachment(Root);
	Structures->SetCollisionProfileName(TEXT("BlockAll"));

	ConstructorHelpers::FObjectFinder<UStaticMesh> Cube(TEXT("/Engine/BasicShapes/Cube.Cube"));
	if (Cube.Succeeded())
	{
		Ground->SetStaticMesh(Cube.Object);
		Structures->SetStaticMesh(Cube.Object);
	}
	else
	{
		UE_LOG(LogUS, Error, TEXT("Nao foi possivel carregar /Engine/BasicShapes/Cube; o distrito ficara vazio."));
	}
}

void AUSProceduralDistrict::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	Generate();
}

void AUSProceduralDistrict::AddBox(const FVector& Center, const FRotator& Rotation, const FVector& SizeCm)
{
	Structures->AddInstance(FTransform(Rotation, Center, SizeCm / CubeSizeCm));
}

FVector AUSProceduralDistrict::GetRandomStreetPoint(FRandomStream& Random, FRotator* OutAlongStreetYaw) const
{
	// As ruas ficam nas bordas entre celulas: x ou y = (i + 0.5) * CellSize, i em [-GridRadius, GridRadius - 1].
	const float Half = GetHalfExtent();
	const int32 LineIndex = Random.RandRange(-GridRadius, GridRadius - 1);
	const float LineCoord = (LineIndex + 0.5f) * CellSize;
	const float Spread = Random.FRandRange(-StreetHalfSpread, StreetHalfSpread);
	const float Along = Random.FRandRange(-Half + 300.f, Half - 300.f);

	const bool bVerticalStreet = Random.RandBool(); // rua paralela ao eixo Y
	FVector Local;
	if (bVerticalStreet)
	{
		Local = FVector(LineCoord + Spread, Along, PawnSpawnHeight);
		if (OutAlongStreetYaw) { *OutAlongStreetYaw = FRotator(0.f, 90.f, 0.f); }
	}
	else
	{
		Local = FVector(Along, LineCoord + Spread, PawnSpawnHeight);
		if (OutAlongStreetYaw) { *OutAlongStreetYaw = FRotator::ZeroRotator; }
	}
	return GetActorTransform().TransformPosition(Local);
}

void AUSProceduralDistrict::Generate()
{
	Structures->ClearInstances();
	FRandomStream Random(Seed);

	const float Half = GetHalfExtent();

	// Chao: cubo achatado cuja face superior fica em z = 0.
	Ground->SetRelativeLocation(FVector(0.f, 0.f, -50.f));
	Ground->SetRelativeScale3D(FVector((Half * 2.f + 800.f) / CubeSizeCm, (Half * 2.f + 800.f) / CubeSizeCm, 1.f));

	// Predios em grade. A praca central (3x3 celulas) fica livre: ali nasce o jogador.
	for (int32 IX = -GridRadius; IX <= GridRadius; ++IX)
	{
		for (int32 IY = -GridRadius; IY <= GridRadius; ++IY)
		{
			if (FMath::Abs(IX) <= 1 && FMath::Abs(IY) <= 1)
			{
				continue;
			}
			if (Random.FRand() > BuildingChance)
			{
				continue; // terreno baldio
			}
			const float SX = Random.FRandRange(800.f, 1200.f);
			const float SY = Random.FRandRange(800.f, 1200.f);
			const float SZ = Random.FRandRange(600.f, 2400.f);
			AddBox(FVector(IX * CellSize, IY * CellSize, SZ * 0.5f), FRotator::ZeroRotator, FVector(SX, SY, SZ));
		}
	}

	// Muro perimetral para o jogador nao cair do mapa.
	const float Wall = 200.f, WallH = 800.f, Span = Half * 2.f + 2.f * Wall;
	AddBox(FVector(0.f, Half + Wall * 0.5f, WallH * 0.5f), FRotator::ZeroRotator, FVector(Span, Wall, WallH));
	AddBox(FVector(0.f, -Half - Wall * 0.5f, WallH * 0.5f), FRotator::ZeroRotator, FVector(Span, Wall, WallH));
	AddBox(FVector(Half + Wall * 0.5f, 0.f, WallH * 0.5f), FRotator::ZeroRotator, FVector(Wall, Span, WallH));
	AddBox(FVector(-Half - Wall * 0.5f, 0.f, WallH * 0.5f), FRotator::ZeroRotator, FVector(Wall, Span, WallH));

	// Caixotes e carcacas de carros nas ruas. Podem se sobrepor entre si; e so cenario de teste.
	for (int32 i = 0; i < CrateCount; ++i)
	{
		const FVector P = GetRandomStreetPoint(Random);
		const FVector Local = GetActorTransform().InverseTransformPosition(P);
		const float S = Random.FRandRange(80.f, 220.f);
		AddBox(FVector(Local.X, Local.Y, S * 0.5f), FRotator(0.f, Random.FRandRange(0.f, 90.f), 0.f), FVector(S, S, S));
	}
	for (int32 i = 0; i < WreckedCarCount; ++i)
	{
		FRotator Along;
		const FVector P = GetRandomStreetPoint(Random, &Along);
		const FVector Local = GetActorTransform().InverseTransformPosition(P);
		// Comprimento ~450 cm no eixo da rua (X local do cubo apos a rotacao), largura ~190, altura ~150.
		AddBox(FVector(Local.X, Local.Y, 75.f), Along + FRotator(0.f, Random.FRandRange(-12.f, 12.f), 0.f), FVector(450.f, 190.f, 150.f));
	}
}
