#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "USGameMode.generated.h"

class AUSInfectedCharacter;
class AUSProceduralDistrict;

/**
 * Regras da partida (single player). Define as classes padrao (personagem, controlador, HUD),
 * garante que o distrito jogavel exista no nivel, povoa o mapa com infectados e reaparece o
 * jogador depois da morte.
 *
 * Funciona em QUALQUER nivel vazio: se o nivel nao contem um AUSProceduralDistrict, este GameMode cria um.
 */
UCLASS()
class ULTIMOSOBREVIVENTE_API AUSGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AUSGameMode();

	/** Chamado pelo personagem ao morrer. Agenda o reaparecimento. */
	void NotifyPlayerDied(AController* DeadController);

	virtual AActor* ChoosePlayerStart_Implementation(AController* Player) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Partida") int32 InfectedCount = 6;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Partida") float RespawnDelaySeconds = 4.f;
	/** Infectados nao nascem a menos desta distancia (cm) do ponto de partida do jogador. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Partida") float MinSpawnDistanceFromPlayer = 2500.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Partida") TSubclassOf<AUSInfectedCharacter> InfectedClass;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Partida") TSubclassOf<AUSProceduralDistrict> DistrictClass;

protected:
	virtual void BeginPlay() override;

private:
	void SpawnInfected(AUSProceduralDistrict* District);
	void RespawnPlayer(TWeakObjectPtr<AController> Controller);

	UPROPERTY() TObjectPtr<AActor> PlayerStartActor;
};
