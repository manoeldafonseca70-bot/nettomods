#include "Mapas/USGameMode.h"
#include "Mapas/USProceduralDistrict.h"
#include "Personagens/USCharacter.h"
#include "Inimigos/USInfectedCharacter.h"
#include "Interface/USPlayerController.h"
#include "Interface/USHUD.h"
#include "UltimoSobrevivente.h"

#include "EngineUtils.h"
#include "Engine/World.h"
#include "GameFramework/PlayerStart.h"
#include "GameFramework/Controller.h"
#include "TimerManager.h"

AUSGameMode::AUSGameMode()
{
	DefaultPawnClass = AUSCharacter::StaticClass();
	PlayerControllerClass = AUSPlayerController::StaticClass();
	HUDClass = AUSHUD::StaticClass();
	InfectedClass = AUSInfectedCharacter::StaticClass();
	DistrictClass = AUSProceduralDistrict::StaticClass();
}

AActor* AUSGameMode::ChoosePlayerStart_Implementation(AController* Player)
{
	// Se o nivel tiver PlayerStart proprio, vale o dele.
	if (UWorld* World = GetWorld())
	{
		for (TActorIterator<APlayerStart> It(World); It; ++It)
		{
			return *It;
		}

		// Senao, cria um na praca central do distrito (livre de predios), a 150 cm do chao.
		if (!PlayerStartActor)
		{
			FActorSpawnParameters Params;
			Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			PlayerStartActor = World->SpawnActor<APlayerStart>(FVector(0.f, 0.f, 150.f), FRotator::ZeroRotator, Params);
		}
	}
	return PlayerStartActor;
}

void AUSGameMode::BeginPlay()
{
	Super::BeginPlay();

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	AUSProceduralDistrict* District = nullptr;
	for (TActorIterator<AUSProceduralDistrict> It(World); It; ++It)
	{
		District = *It;
		break;
	}
	if (!District)
	{
		FActorSpawnParameters Params;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		const TSubclassOf<AUSProceduralDistrict> Class = DistrictClass ? DistrictClass : TSubclassOf<AUSProceduralDistrict>(AUSProceduralDistrict::StaticClass());
		District = World->SpawnActor<AUSProceduralDistrict>(Class, FTransform::Identity, Params);
	}

	if (District)
	{
		SpawnInfected(District);
	}
	else
	{
		UE_LOG(LogUS, Error, TEXT("Nao foi possivel criar o distrito jogavel."));
	}
}

void AUSGameMode::SpawnInfected(AUSProceduralDistrict* District)
{
	UWorld* World = GetWorld();
	if (!World || !InfectedClass || InfectedCount <= 0)
	{
		return;
	}

	FRandomStream Random;
	Random.GenerateNewSeed();

	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	int32 Spawned = 0;
	for (int32 i = 0; i < InfectedCount; ++i)
	{
		FVector Location = FVector::ZeroVector;
		bool bFound = false;
		for (int32 Attempt = 0; Attempt < 20 && !bFound; ++Attempt)
		{
			Location = District->GetRandomStreetPoint(Random);
			bFound = FVector::Dist2D(Location, District->GetActorLocation()) >= MinSpawnDistanceFromPlayer;
		}
		if (!bFound)
		{
			continue;
		}
		const FRotator Rotation(0.f, Random.FRandRange(0.f, 360.f), 0.f);
		if (World->SpawnActor<AUSInfectedCharacter>(InfectedClass, Location, Rotation, Params))
		{
			++Spawned;
		}
	}
	UE_LOG(LogUS, Log, TEXT("Infectados criados: %d de %d"), Spawned, InfectedCount);
}

void AUSGameMode::NotifyPlayerDied(AController* DeadController)
{
	if (!DeadController || !GetWorld())
	{
		return;
	}
	FTimerHandle Handle; // o gerenciador de timers mantem o delegate vivo; o handle local pode sair de escopo
	GetWorld()->GetTimerManager().SetTimer(Handle, FTimerDelegate::CreateUObject(this, &AUSGameMode::RespawnPlayer, TWeakObjectPtr<AController>(DeadController)), FMath::Max(0.5f, RespawnDelaySeconds), false);
}

void AUSGameMode::RespawnPlayer(TWeakObjectPtr<AController> Controller)
{
	if (AController* C = Controller.Get())
	{
		if (!C->GetPawn())
		{
			RestartPlayer(C);
		}
	}
}
