#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "USProceduralDistrict.generated.h"

class UStaticMeshComponent;
class UInstancedStaticMeshComponent;

/**
 * Primeiro cenario explorável: um quarteirao urbano gerado por codigo (ruas em grade, predios,
 * caixotes e carcacas de carros, muro perimetral, praca livre no centro onde o jogador nasce).
 *
 * E um bloco de teste jogavel feito de CUBOS da engine (/Engine/BasicShapes/Cube), sem texturas nem
 * interiores. Nao e o cenario final nem tem a qualidade visual do briefing: isso exige assets
 * (Quixel/Fab etc.) importados no editor. A geracao e deterministica pela Seed.
 * Todas as instancias ficam em UM UInstancedStaticMeshComponent (1 draw call para toda a estrutura).
 */
UCLASS()
class ULTIMOSOBREVIVENTE_API AUSProceduralDistrict : public AActor
{
	GENERATED_BODY()

public:
	AUSProceduralDistrict();

	virtual void OnConstruction(const FTransform& Transform) override;

	/** Ponto aleatorio no meio de uma rua, em coordenadas de mundo, na altura de spawn de pawns. */
	FVector GetRandomStreetPoint(FRandomStream& Random, FRotator* OutAlongStreetYaw = nullptr) const;

	/** Metade do lado da area jogavel, em cm. */
	float GetHalfExtent() const { return (GridRadius + 0.5f) * CellSize; }

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Distrito") int32 Seed = 2041;
	/** O quarteirao tem (2*GridRadius+1)^2 celulas. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Distrito", meta = (ClampMin = "2", ClampMax = "12")) int32 GridRadius = 4;
	/** Lado de cada celula (predio + rua), em cm. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Distrito", meta = (ClampMin = "1500")) float CellSize = 2000.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Distrito", meta = (ClampMin = "0.0", ClampMax = "1.0")) float BuildingChance = 0.85f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Distrito") int32 CrateCount = 90;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Distrito") int32 WreckedCarCount = 35;

private:
	void Generate();
	void AddBox(const FVector& Center, const FRotator& Rotation, const FVector& SizeCm);

	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<USceneComponent> Root;
	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<UStaticMeshComponent> Ground;
	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<UInstancedStaticMeshComponent> Structures;
};
