#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UObject/ConstructorHelpers.h"

/**
 * Corpo provisorio (cilindro + "nariz" cubica indicando a frente) feito com formas basicas da engine.
 * Existe porque o projeto ainda nao tem malha esqueletica humana. Quando uma USkeletalMesh e atribuida
 * ao Mesh do personagem, o corpo provisorio e escondido automaticamente.
 * CreatePlaceholderBody() so pode ser chamada dentro do construtor do personagem.
 */
namespace USPlaceholder
{
	inline void CreatePlaceholderBody(ACharacter& Owner, TObjectPtr<UStaticMeshComponent>& OutBody, TObjectPtr<UStaticMeshComponent>& OutNose)
	{
		ConstructorHelpers::FObjectFinder<UStaticMesh> Cylinder(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
		ConstructorHelpers::FObjectFinder<UStaticMesh> Cube(TEXT("/Engine/BasicShapes/Cube.Cube"));

		OutBody = Owner.CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PlaceholderBody"));
		OutBody->SetupAttachment(Owner.GetCapsuleComponent());
		OutBody->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		OutBody->SetGenerateOverlapEvents(false);
		OutBody->SetRelativeLocation(FVector(0.f, 0.f, -3.f));
		OutBody->SetRelativeScale3D(FVector(0.6f, 0.6f, 1.7f)); // ~60 cm de diametro x 170 cm de altura
		if (Cylinder.Succeeded())
		{
			OutBody->SetStaticMesh(Cylinder.Object);
		}

		OutNose = Owner.CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PlaceholderNose"));
		OutNose->SetupAttachment(Owner.GetCapsuleComponent());
		OutNose->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		OutNose->SetGenerateOverlapEvents(false);
		OutNose->SetRelativeLocation(FVector(30.f, 0.f, 45.f));
		OutNose->SetRelativeScale3D(FVector(0.25f, 0.25f, 0.25f));
		if (Cube.Succeeded())
		{
			OutNose->SetStaticMesh(Cube.Object);
		}
	}

	/** Esconde o corpo provisorio se o personagem ja tem malha esqueletica; senao aplica a cor. */
	inline void FinalizePlaceholderBody(ACharacter& Owner, UStaticMeshComponent* Body, UStaticMeshComponent* Nose, const FLinearColor& Tint)
	{
		if (!Body || !Nose)
		{
			return;
		}
		if (Owner.GetMesh() && Owner.GetMesh()->GetSkeletalMeshAsset())
		{
			Body->SetVisibility(false);
			Nose->SetVisibility(false);
			return;
		}
		// O parametro "Color" depende do material padrao das formas basicas; se nao existir, nada acontece.
		if (UMaterialInstanceDynamic* Mid = Body->CreateDynamicMaterialInstance(0))
		{
			Mid->SetVectorParameterValue(TEXT("Color"), Tint);
		}
		if (UMaterialInstanceDynamic* MidNose = Nose->CreateDynamicMaterialInstance(0))
		{
			MidNose->SetVectorParameterValue(TEXT("Color"), FLinearColor::White);
		}
	}
}
