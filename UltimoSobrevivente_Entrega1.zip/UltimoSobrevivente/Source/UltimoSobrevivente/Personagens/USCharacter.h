#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "USCharacter.generated.h"

class USpringArmComponent;
class UCameraComponent;
class UStaticMeshComponent;
class UUSHealthComponent;
class UUSWeaponComponent;
class UAIPerceptionStimuliSourceComponent;

/**
 * Personagem do jogador em terceira pessoa.
 * Camera por SpringArm (distancia ajustavel, zoom ao mirar), movimentacao completa
 * (andar, correr, sprint, agachar, pular), vida/dano e armas.
 *
 * Toda entrada passa pela API Input* abaixo: teclado/mouse (para testar no editor) chama essas funcoes
 * daqui, e o touch chama as mesmas pelo AUSPlayerController.
 *
 * Ainda NAO implementados: escalada, natacao, interacao com objetos, animacoes de ferimento/morte.
 */
UCLASS()
class ULTIMOSOBREVIVENTE_API AUSCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	AUSCharacter();

	virtual void Tick(float DeltaSeconds) override;
	virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

	// ---- API de entrada (teclado e touch usam as mesmas funcoes) ----
	/** X = direita, Y = frente. Magnitude 0..1 (analogico do joystick virtual). */
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputMoveTouch(FVector2D Axis) { TouchMove = Axis.GetClampedToMaxSize(1.f); }
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputLookTouchPixels(float DeltaX, float DeltaY);
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputJump(bool bPressed);
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputSprint(bool bHeld);
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputCrouchToggle();
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputFire(bool bPressed);
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputAim(bool bHeld);
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputReload();
	UFUNCTION(BlueprintCallable, Category = "US|Entrada") void InputNextWeapon();

	// ---- Configuracoes de camera / sensibilidade (a tela de configuracoes futura usa estas funcoes) ----
	UFUNCTION(BlueprintCallable, Category = "US|Camera") void SetCameraDistance(float NewDistance);
	UFUNCTION(BlueprintCallable, Category = "US|Camera") void SetTouchLookSensitivity(float NewValue) { TouchLookSensitivity = FMath::Max(0.01f, NewValue); }

	UFUNCTION(BlueprintPure, Category = "US|Estado") bool IsAiming() const { return bAiming; }
	UFUNCTION(BlueprintPure, Category = "US|Estado") bool IsSprinting() const { return bSprinting; }
	UFUNCTION(BlueprintPure, Category = "US|Estado") bool IsDead() const { return bDead; }

	UUSHealthComponent* GetHealthComponent() const { return Health; }
	UUSWeaponComponent* GetWeaponComponent() const { return Weapon; }

	// ---- Velocidades em cm/s (provisorias, nao calibradas) ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Movimento") float WalkSpeed = 200.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Movimento") float RunSpeed = 400.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Movimento") float SprintSpeed = 600.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Movimento") float CrouchSpeed = 150.f;
	/** Fracao da velocidade mantida ao mirar. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Movimento") float AimSpeedFactor = 0.6f;
	/** Abaixo desta inclinacao do joystick (0..1) o personagem anda em vez de correr. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Movimento") float WalkStickThreshold = 0.55f;

	// ---- Camera ----
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Camera") float CameraDistance = 320.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Camera") float AimCameraDistance = 170.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Camera") float DefaultFOV = 90.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Camera") float AimFOV = 70.f;
	/** Graus por pixel arrastado no touch. NAO calibrado em aparelho real. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Camera") float TouchLookSensitivity = 0.15f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Camera") float MouseSensitivity = 1.0f;

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void HandleDeath(UUSHealthComponent* Component, AController* Killer);

private:
	void UpdateMovement(float DeltaSeconds);
	void UpdateCamera(float DeltaSeconds);
	void UpdateNoise(float DeltaSeconds);

	// Teclado e mouse (somente para testes no editor / PC)
	void KeyForward(float V) { KeyW = V; }
	void KeyBackward(float V) { KeyS = V; }
	void KeyRight(float V) { KeyD = V; }
	void KeyLeft(float V) { KeyA = V; }
	void MouseLookYaw(float V);
	void MouseLookPitch(float V);
	void JumpPressed() { InputJump(true); }
	void JumpReleased() { InputJump(false); }
	void SprintPressed() { InputSprint(true); }
	void SprintReleased() { InputSprint(false); }
	void FirePressed() { InputFire(true); }
	void FireReleased() { InputFire(false); }
	void AimPressed() { InputAim(true); }
	void AimReleased() { InputAim(false); }

	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<USpringArmComponent> CameraBoom;
	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<UCameraComponent> FollowCamera;
	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<UUSHealthComponent> Health;
	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<UUSWeaponComponent> Weapon;
	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<UAIPerceptionStimuliSourceComponent> StimuliSource;
	UPROPERTY() TObjectPtr<UStaticMeshComponent> PlaceholderBody;
	UPROPERTY() TObjectPtr<UStaticMeshComponent> PlaceholderNose;

	FVector2D TouchMove = FVector2D::ZeroVector;
	float KeyW = 0.f, KeyS = 0.f, KeyA = 0.f, KeyD = 0.f;
	bool bSprintHeld = false;
	bool bSprinting = false;
	bool bAiming = false;
	bool bDead = false;
	float NoiseTimer = 0.f;
};
