#include "Personagens/USCharacter.h"
#include "Personagens/USPlaceholderBody.h"
#include "Sobrevivencia/USHealthComponent.h"
#include "Armas/USWeaponComponent.h"
#include "Mapas/USGameMode.h"
#include "UltimoSobrevivente.h"

#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/Controller.h"
#include "Perception/AIPerceptionStimuliSourceComponent.h"
#include "Perception/AISense_Sight.h"
#include "Perception/AISense_Hearing.h"
#include "Components/InputComponent.h"
#include "InputCoreTypes.h"
#include "Engine/World.h"

AUSCharacter::AUSCharacter()
{
	PrimaryActorTick.bCanEverTick = true;

	GetCapsuleComponent()->InitCapsuleSize(34.f, 88.f);

	// A rotacao e decidida em Tick: acompanha o movimento, ou a camera ao mirar/atirar.
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	UCharacterMovementComponent* Move = GetCharacterMovement();
	Move->bOrientRotationToMovement = true;
	Move->RotationRate = FRotator(0.f, 540.f, 0.f);
	Move->JumpZVelocity = 420.f;
	Move->AirControl = 0.3f;
	Move->MaxWalkSpeed = RunSpeed;
	Move->MaxWalkSpeedCrouched = CrouchSpeed;
	Move->BrakingDecelerationWalking = 2000.f;
	Move->GetNavAgentPropertiesRef().bCanCrouch = true;

	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->TargetArmLength = CameraDistance;
	CameraBoom->bUsePawnControlRotation = true;
	CameraBoom->bDoCollisionTest = true;
	CameraBoom->SocketOffset = FVector(0.f, 45.f, 55.f); // sobre o ombro direito
	CameraBoom->bEnableCameraLag = true;
	CameraBoom->CameraLagSpeed = 18.f;

	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
	FollowCamera->bUsePawnControlRotation = false;
	FollowCamera->SetFieldOfView(DefaultFOV);

	Health = CreateDefaultSubobject<UUSHealthComponent>(TEXT("Health"));
	Weapon = CreateDefaultSubobject<UUSWeaponComponent>(TEXT("Weapon"));
	StimuliSource = CreateDefaultSubobject<UAIPerceptionStimuliSourceComponent>(TEXT("StimuliSource"));

	USPlaceholder::CreatePlaceholderBody(*this, PlaceholderBody, PlaceholderNose);
}

void AUSCharacter::BeginPlay()
{
	Super::BeginPlay();

	if (StimuliSource)
	{
		StimuliSource->RegisterForSense(UAISense_Sight::StaticClass());
	}
	if (Health)
	{
		Health->OnDeath.AddDynamic(this, &AUSCharacter::HandleDeath);
	}

	GetCharacterMovement()->MaxWalkSpeedCrouched = CrouchSpeed;
	CameraBoom->TargetArmLength = CameraDistance;
	FollowCamera->SetFieldOfView(DefaultFOV);

	USPlaceholder::FinalizePlaceholderBody(*this, PlaceholderBody, PlaceholderNose, FLinearColor(0.1f, 0.35f, 0.9f));
}

void AUSCharacter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	if (bDead)
	{
		return;
	}
	UpdateMovement(DeltaSeconds);
	UpdateCamera(DeltaSeconds);
	UpdateNoise(DeltaSeconds);
}

void AUSCharacter::UpdateMovement(float DeltaSeconds)
{
	// Touch tem prioridade quando ha dedo no joystick; senao vale o teclado.
	const FVector2D KeyboardInput(KeyD - KeyA, KeyW - KeyS);
	const FVector2D Input = TouchMove.SizeSquared() > 0.0025f ? TouchMove : KeyboardInput.GetClampedToMaxSize(1.f);
	const float Magnitude = FMath::Min(Input.Size(), 1.f);
	const bool bMoving = Magnitude > 0.05f && Controller != nullptr;

	if (bMoving)
	{
		const FRotator YawRotation(0.f, Controller->GetControlRotation().Yaw, 0.f);
		const FVector Forward = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		const FVector Right = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
		const FVector2D Dir = Input.GetSafeNormal();
		AddMovementInput(Forward * Dir.Y + Right * Dir.X, 1.f); // velocidade e escolhida por MaxWalkSpeed
	}

	// Sprint so para frente, em pe e sem mirar.
	bSprinting = bSprintHeld && bMoving && !bIsCrouched && !bAiming && Input.Y > 0.1f;

	float Speed = bSprinting ? SprintSpeed : (Magnitude < WalkStickThreshold ? WalkSpeed : RunSpeed);
	if (bAiming)
	{
		Speed *= AimSpeedFactor;
	}
	UCharacterMovementComponent* Move = GetCharacterMovement();
	Move->MaxWalkSpeed = Speed;
	Move->MaxWalkSpeedCrouched = CrouchSpeed;

	// Ao mirar ou atirar, o corpo acompanha a camera; caso contrario, acompanha o movimento.
	const bool bFaceControl = bAiming || (Weapon && Weapon->IsTriggerHeld());
	bUseControllerRotationYaw = bFaceControl;
	Move->bOrientRotationToMovement = !bFaceControl;
}

void AUSCharacter::UpdateCamera(float DeltaSeconds)
{
	const float TargetArm = bAiming ? AimCameraDistance : CameraDistance;
	const float TargetFOV = bAiming ? AimFOV : DefaultFOV;
	CameraBoom->TargetArmLength = FMath::FInterpTo(CameraBoom->TargetArmLength, TargetArm, DeltaSeconds, 10.f);
	FollowCamera->SetFieldOfView(FMath::FInterpTo(FollowCamera->FieldOfView, TargetFOV, DeltaSeconds, 10.f));
}

void AUSCharacter::UpdateNoise(float DeltaSeconds)
{
	// Passos geram ruido; agachado e andando nao. Alcances provisorios, nao calibrados.
	const float Speed2D = GetVelocity().Size2D();
	if (bIsCrouched || Speed2D <= WalkSpeed + 10.f || !GetCharacterMovement()->IsMovingOnGround())
	{
		NoiseTimer = 0.f;
		return;
	}
	NoiseTimer -= DeltaSeconds;
	if (NoiseTimer <= 0.f)
	{
		NoiseTimer = 0.4f;
		UAISense_Hearing::ReportNoiseEvent(GetWorld(), GetActorLocation(), bSprinting ? 1.f : 0.5f, this, bSprinting ? 1500.f : 800.f, FName(TEXT("Footstep")));
	}
}

// ---------------------------------------------------------------- entrada

void AUSCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	check(PlayerInputComponent);

	// Bindings diretos por tecla: nao exigem assets de Input Mapping. Migrar para Enhanced Input fica
	// como melhoria futura (menu de remapeamento de teclas).
	PlayerInputComponent->BindAxisKey(EKeys::W, this, &AUSCharacter::KeyForward);
	PlayerInputComponent->BindAxisKey(EKeys::S, this, &AUSCharacter::KeyBackward);
	PlayerInputComponent->BindAxisKey(EKeys::D, this, &AUSCharacter::KeyRight);
	PlayerInputComponent->BindAxisKey(EKeys::A, this, &AUSCharacter::KeyLeft);
	PlayerInputComponent->BindAxisKey(EKeys::MouseX, this, &AUSCharacter::MouseLookYaw);
	PlayerInputComponent->BindAxisKey(EKeys::MouseY, this, &AUSCharacter::MouseLookPitch);

	PlayerInputComponent->BindKey(EKeys::SpaceBar, IE_Pressed, this, &AUSCharacter::JumpPressed);
	PlayerInputComponent->BindKey(EKeys::SpaceBar, IE_Released, this, &AUSCharacter::JumpReleased);
	PlayerInputComponent->BindKey(EKeys::LeftShift, IE_Pressed, this, &AUSCharacter::SprintPressed);
	PlayerInputComponent->BindKey(EKeys::LeftShift, IE_Released, this, &AUSCharacter::SprintReleased);
	PlayerInputComponent->BindKey(EKeys::C, IE_Pressed, this, &AUSCharacter::InputCrouchToggle);
	PlayerInputComponent->BindKey(EKeys::LeftMouseButton, IE_Pressed, this, &AUSCharacter::FirePressed);
	PlayerInputComponent->BindKey(EKeys::LeftMouseButton, IE_Released, this, &AUSCharacter::FireReleased);
	PlayerInputComponent->BindKey(EKeys::RightMouseButton, IE_Pressed, this, &AUSCharacter::AimPressed);
	PlayerInputComponent->BindKey(EKeys::RightMouseButton, IE_Released, this, &AUSCharacter::AimReleased);
	PlayerInputComponent->BindKey(EKeys::R, IE_Pressed, this, &AUSCharacter::InputReload);
	PlayerInputComponent->BindKey(EKeys::Q, IE_Pressed, this, &AUSCharacter::InputNextWeapon);
}

void AUSCharacter::MouseLookYaw(float V)
{
	if (!bDead && V != 0.f) { AddControllerYawInput(V * MouseSensitivity); }
}

void AUSCharacter::MouseLookPitch(float V)
{
	// Mouse para cima = valor positivo; AddControllerPitchInput negativo olha para cima.
	if (!bDead && V != 0.f) { AddControllerPitchInput(-V * MouseSensitivity); }
}

void AUSCharacter::InputLookTouchPixels(float DeltaX, float DeltaY)
{
	if (bDead) { return; }
	// Arrastar o dedo para cima (DeltaY negativo) olha para cima.
	AddControllerYawInput(DeltaX * TouchLookSensitivity);
	AddControllerPitchInput(DeltaY * TouchLookSensitivity);
}

void AUSCharacter::InputJump(bool bPressed)
{
	if (bDead) { return; }
	if (bPressed) { Jump(); } else { StopJumping(); }
}

void AUSCharacter::InputSprint(bool bHeld) { bSprintHeld = bHeld && !bDead; }

void AUSCharacter::InputCrouchToggle()
{
	if (bDead) { return; }
	if (bIsCrouched) { UnCrouch(); } else { Crouch(); }
}

void AUSCharacter::InputFire(bool bPressed)
{
	if (!Weapon) { return; }
	if (bPressed && !bDead) { Weapon->StartFire(); } else { Weapon->StopFire(); }
}

void AUSCharacter::InputAim(bool bHeld) { bAiming = bHeld && !bDead; }
void AUSCharacter::InputReload() { if (Weapon && !bDead) { Weapon->Reload(); } }
void AUSCharacter::InputNextWeapon() { if (Weapon && !bDead) { Weapon->NextWeapon(); } }

void AUSCharacter::SetCameraDistance(float NewDistance)
{
	CameraDistance = FMath::Clamp(NewDistance, 150.f, 700.f);
}

// ---------------------------------------------------------------- morte

void AUSCharacter::HandleDeath(UUSHealthComponent* Component, AController* Killer)
{
	if (bDead) { return; }
	bDead = true;
	bSprintHeld = false;
	bAiming = false;
	TouchMove = FVector2D::ZeroVector;

	if (Weapon) { Weapon->StopFire(); }
	if (StimuliSource) { StimuliSource->UnregisterFromPerceptionSystem(); }

	GetCharacterMovement()->DisableMovement();
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	if (GetMesh() && GetMesh()->GetSkeletalMeshAsset())
	{
		// Ragdoll simples. Animacao de morte propria depende de assets.
		GetMesh()->SetCollisionProfileName(TEXT("Ragdoll"));
		GetMesh()->SetSimulatePhysics(true);
	}
	else if (PlaceholderBody)
	{
		PlaceholderBody->SetRelativeRotation(FRotator(90.f, 0.f, 0.f)); // "tomba" o corpo provisorio
	}

	AController* DeadController = GetController();
	DetachFromControllerPendingDestroy();
	SetLifeSpan(6.f);

	if (AUSGameMode* GameMode = GetWorld() ? GetWorld()->GetAuthGameMode<AUSGameMode>() : nullptr)
	{
		GameMode->NotifyPlayerDied(DeadController);
	}
}
