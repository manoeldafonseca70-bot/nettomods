#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "USInfectedCharacter.generated.h"

class UStaticMeshComponent;
class UAnimMontage;
class UUSHealthComponent;

/**
 * INFECTADO: inimigo basico. O comportamento (patrulha, investigacao, perseguicao, ataque) esta em
 * AUSInfectedAIController; aqui ficam o corpo, a vida, os parametros e o golpe.
 * Atributos sao por instancia/Blueprint, entao futuros inimigos (Cacador, Colosso, Silencioso) podem
 * herdar desta classe mudando velocidade, vida, alcance de percepcao e dano.
 */
UCLASS()
class ULTIMOSOBREVIVENTE_API AUSInfectedCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	AUSInfectedCharacter();

	UFUNCTION(BlueprintPure, Category = "US|Infectado") bool IsDead() const { return bDead; }

	/** Aplica o golpe se o alvo estiver ao alcance. Retorna true se acertou. */
	bool PerformAttack(AActor* Target);

	void SetMoveSpeed(float Speed);

	// Velocidades em cm/s, provisorias e nao calibradas.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Infectado") float PatrolSpeed = 110.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Infectado") float InvestigateSpeed = 200.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Infectado") float ChaseSpeed = 380.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Infectado") float AttackDamage = 15.f;
	/** Distancia (cm) a partir da qual o infectado comeca a atacar. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Infectado") float AttackRange = 150.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Infectado") float AttackCooldown = 1.2f;

	/** Opcional: montagem de ataque. Sem animacao atribuida, o golpe acontece mesmo assim. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Infectado") TObjectPtr<UAnimMontage> AttackMontage;

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void HandleDeath(UUSHealthComponent* Component, AController* Killer);

private:
	UPROPERTY(VisibleAnywhere, Category = "US|Componentes") TObjectPtr<UUSHealthComponent> Health;
	UPROPERTY() TObjectPtr<UStaticMeshComponent> PlaceholderBody;
	UPROPERTY() TObjectPtr<UStaticMeshComponent> PlaceholderNose;

	bool bDead = false;
};
