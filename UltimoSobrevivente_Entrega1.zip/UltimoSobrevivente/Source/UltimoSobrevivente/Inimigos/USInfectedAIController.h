#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "Perception/AIPerceptionTypes.h"
#include "USInfectedAIController.generated.h"

class AUSInfectedCharacter;
class UAISenseConfig_Sight;
class UAISenseConfig_Hearing;

UENUM(BlueprintType)
enum class EUSInfectedState : uint8
{
	Patrol,
	Investigate,
	Chase,
	Attack,
	Dead
};

/**
 * Cerebro do Infectado: maquina de estados em C++ (sem Behavior Tree, que e asset binario).
 *
 *  Patrol      anda entre pontos aleatorios perto do ponto de origem, com pausas.
 *  Investigate vai ate o ultimo ruido ou ultima posicao vista do alvo, olha ao redor, volta a patrulhar.
 *  Chase       persegue o alvo visto; se perde de vista, investiga a ultima posicao conhecida.
 *  Attack      ao alcance, encara o alvo e golpeia com recarga entre golpes.
 *
 * Percepcao: visao (cone) e audicao. Passos e tiros do jogador emitem ruido (ver AUSCharacter / UUSWeaponComponent).
 * Navegacao: usa NavMesh. Se nao houver NavMesh no nivel, cai em movimento direto (sem desviar de obstaculos).
 */
UCLASS()
class ULTIMOSOBREVIVENTE_API AUSInfectedAIController : public AAIController
{
	GENERATED_BODY()

public:
	AUSInfectedAIController();

	virtual void Tick(float DeltaSeconds) override;

	void NotifyPawnDied();

	UFUNCTION(BlueprintPure, Category = "US|IA") EUSInfectedState GetState() const { return State; }

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|IA") float PatrolRadius = 1500.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|IA") float InvestigateDuration = 4.f;
	/** Se o alvo ficar mais longe que isto (cm), o infectado desiste e investiga a ultima posicao. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|IA") float LoseTargetDistance = 3500.f;

protected:
	virtual void OnPossess(APawn* InPawn) override;

	UFUNCTION()
	void OnTargetPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus);

private:
	void EnterState(EUSInfectedState NewState);
	void UpdatePatrol(float Now);
	void UpdateInvestigate(float Now, float DeltaSeconds);
	void UpdateChase(float Now);
	void UpdateAttack(float Now);

	void MoveToPoint(const FVector& Destination, float AcceptanceRadius);
	void StopAllMovement();
	bool IsMovingToDestination() const;
	bool PickPatrolPoint(FVector& OutPoint) const;
	bool IsValidTarget(const AActor* Target) const;
	void FaceLocation(const FVector& Location, float DeltaSeconds, float TurnSpeedDegPerSec) const;

	UPROPERTY() TObjectPtr<AUSInfectedCharacter> Infected;
	UPROPERTY() TObjectPtr<UAISenseConfig_Sight> SightConfig;
	UPROPERTY() TObjectPtr<UAISenseConfig_Hearing> HearingConfig;
	UPROPERTY() TObjectPtr<AActor> TargetActor;

	EUSInfectedState State = EUSInfectedState::Patrol;
	FVector HomeLocation = FVector::ZeroVector;
	FVector InvestigatePoint = FVector::ZeroVector;
	FVector DirectDestination = FVector::ZeroVector;
	float DirectAcceptance = 80.f;
	bool bDirectMoving = false;
	bool bPatrolMoving = false;
	float NextPatrolTime = 0.f;
	float InvestigateUntil = 0.f;
	float NextRepathTime = 0.f;
	float NextAttackTime = 0.f;
};
