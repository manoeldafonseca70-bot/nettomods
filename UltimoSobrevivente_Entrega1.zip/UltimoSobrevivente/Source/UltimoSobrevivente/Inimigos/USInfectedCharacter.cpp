#include "Inimigos/USInfectedCharacter.h"
#include "Inimigos/USInfectedAIController.h"
#include "Personagens/USPlaceholderBody.h"
#include "Sobrevivencia/USHealthComponent.h"
#include "UltimoSobrevivente.h"

#include "Animation/AnimMontage.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/DamageType.h"
#include "Kismet/GameplayStatics.h"

AUSInfectedCharacter::AUSInfectedCharacter()
{
	PrimaryActorTick.bCanEverTick = false;

	GetCapsuleComponent()->InitCapsuleSize(34.f, 88.f);

	bUseControllerRotationYaw = false;
	UCharacterMovementComponent* Move = GetCharacterMovement();
	Move->bOrientRotationToMovement = true;
	Move->RotationRate = FRotator(0.f, 360.f, 0.f);
	Move->MaxWalkSpeed = PatrolSpeed;

	AIControllerClass = AUSInfectedAIController::StaticClass();
	AutoPossessAI = EAutoPossessAI::PlacedInWorldOrSpawned;

	Health = CreateDefaultSubobject<UUSHealthComponent>(TEXT("Health"));
	Health->MaxHealth = 100.f;

	USPlaceholder::CreatePlaceholderBody(*this, PlaceholderBody, PlaceholderNose);
}

void AUSInfectedCharacter::BeginPlay()
{
	Super::BeginPlay();

	Health->OnDeath.AddDynamic(this, &AUSInfectedCharacter::HandleDeath);
	USPlaceholder::FinalizePlaceholderBody(*this, PlaceholderBody, PlaceholderNose, FLinearColor(0.8f, 0.05f, 0.05f));
}

void AUSInfectedCharacter::SetMoveSpeed(float Speed)
{
	GetCharacterMovement()->MaxWalkSpeed = Speed;
}

bool AUSInfectedCharacter::PerformAttack(AActor* Target)
{
	if (bDead || !Target)
	{
		return false;
	}

	if (AttackMontage)
	{
		PlayAnimMontage(AttackMontage);
	}

	// Confere o alcance no momento do golpe (o alvo pode ter se afastado).
	const float Distance2D = FVector::Dist2D(GetActorLocation(), Target->GetActorLocation());
	if (Distance2D > AttackRange * 1.25f)
	{
		return false;
	}

	UGameplayStatics::ApplyDamage(Target, AttackDamage, GetController(), this, UDamageType::StaticClass());
	return true;
}

void AUSInfectedCharacter::HandleDeath(UUSHealthComponent* Component, AController* Killer)
{
	if (bDead)
	{
		return;
	}
	bDead = true;

	if (AUSInfectedAIController* AI = Cast<AUSInfectedAIController>(GetController()))
	{
		AI->NotifyPawnDied();
	}

	GetCharacterMovement()->DisableMovement();
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	if (GetMesh() && GetMesh()->GetSkeletalMeshAsset())
	{
		GetMesh()->SetCollisionProfileName(TEXT("Ragdoll"));
		GetMesh()->SetSimulatePhysics(true);
	}
	else if (PlaceholderBody)
	{
		PlaceholderBody->SetRelativeRotation(FRotator(90.f, 0.f, 0.f));
	}

	DetachFromControllerPendingDestroy();
	SetLifeSpan(10.f);
}
