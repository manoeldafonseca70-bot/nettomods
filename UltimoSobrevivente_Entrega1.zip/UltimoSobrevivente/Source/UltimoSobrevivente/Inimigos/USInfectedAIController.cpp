#include "Inimigos/USInfectedAIController.h"
#include "Inimigos/USInfectedCharacter.h"
#include "Personagens/USCharacter.h"
#include "Sobrevivencia/USHealthComponent.h"
#include "UltimoSobrevivente.h"

#include "NavigationSystem.h"
#include "Navigation/PathFollowingComponent.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AISenseConfig_Hearing.h"
#include "Perception/AISense_Sight.h"
#include "Perception/AISense_Hearing.h"
#include "Engine/World.h"

AUSInfectedAIController::AUSInfectedAIController()
{
	PrimaryActorTick.bCanEverTick = true;

	SetPerceptionComponent(*CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("AIPerception")));

	SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("SightConfig"));
	SightConfig->SightRadius = 2200.f;
	SightConfig->LoseSightRadius = 2600.f;
	SightConfig->PeripheralVisionAngleDegrees = 75.f;
	// Sem sistema de times, o jogador e "neutro" para a IA; por isso detectamos tudo.
	SightConfig->DetectionByAffiliation.bDetectEnemies = true;
	SightConfig->DetectionByAffiliation.bDetectNeutrals = true;
	SightConfig->DetectionByAffiliation.bDetectFriendlies = true;

	HearingConfig = CreateDefaultSubobject<UAISenseConfig_Hearing>(TEXT("HearingConfig"));
	HearingConfig->HearingRange = 3500.f;
	HearingConfig->DetectionByAffiliation.bDetectEnemies = true;
	HearingConfig->DetectionByAffiliation.bDetectNeutrals = true;
	HearingConfig->DetectionByAffiliation.bDetectFriendlies = true;

	GetPerceptionComponent()->ConfigureSense(*SightConfig);
	GetPerceptionComponent()->ConfigureSense(*HearingConfig);
	GetPerceptionComponent()->SetDominantSense(SightConfig->GetSenseImplementation());
	GetPerceptionComponent()->OnTargetPerceptionUpdated.AddDynamic(this, &AUSInfectedAIController::OnTargetPerceptionUpdated);
}

void AUSInfectedAIController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);

	Infected = Cast<AUSInfectedCharacter>(InPawn);
	if (Infected)
	{
		HomeLocation = Infected->GetActorLocation();
		EnterState(EUSInfectedState::Patrol);
	}
}

void AUSInfectedAIController::NotifyPawnDied()
{
	StopAllMovement();
	State = EUSInfectedState::Dead;
	TargetActor = nullptr;
}

bool AUSInfectedAIController::IsValidTarget(const AActor* Target) const
{
	if (!IsValid(Target))
	{
		return false;
	}
	const UUSHealthComponent* TargetHealth = Target->FindComponentByClass<UUSHealthComponent>();
	return !(TargetHealth && TargetHealth->IsDead());
}

// ------------------------------------------------------------ percepcao

void AUSInfectedAIController::OnTargetPerceptionUpdated(AActor* Actor, FAIStimulus Stimulus)
{
	if (State == EUSInfectedState::Dead || !Infected || !Actor || !Actor->IsA<AUSCharacter>() || !IsValidTarget(Actor))
	{
		return;
	}

	const bool bIsSight = Stimulus.Type == UAISense::GetSenseID<UAISense_Sight>();
	const bool bIsHearing = Stimulus.Type == UAISense::GetSenseID<UAISense_Hearing>();

	if (bIsSight)
	{
		if (Stimulus.WasSuccessfullySensed())
		{
			TargetActor = Actor;
			if (State != EUSInfectedState::Attack && State != EUSInfectedState::Chase)
			{
				EnterState(EUSInfectedState::Chase);
			}
		}
		else if (TargetActor == Actor)
		{
			// Perdeu de vista: investiga onde viu pela ultima vez.
			TargetActor = nullptr;
			InvestigatePoint = Stimulus.StimulusLocation;
			EnterState(EUSInfectedState::Investigate);
		}
	}
	else if (bIsHearing && Stimulus.WasSuccessfullySensed())
	{
		// Ruido so desvia a atencao se ainda nao ha alvo visto.
		if (!TargetActor)
		{
			InvestigatePoint = Stimulus.StimulusLocation;
			EnterState(EUSInfectedState::Investigate);
		}
	}
}

// ------------------------------------------------------------ maquina de estados

void AUSInfectedAIController::EnterState(EUSInfectedState NewState)
{
	if (!Infected || State == EUSInfectedState::Dead)
	{
		return;
	}

	State = NewState;
	NextRepathTime = 0.f;
	InvestigateUntil = 0.f;
	bPatrolMoving = false;
	StopAllMovement();

	switch (NewState)
	{
	case EUSInfectedState::Patrol:
		Infected->SetMoveSpeed(Infected->PatrolSpeed);
		NextPatrolTime = 0.f;
		break;
	case EUSInfectedState::Investigate:
		Infected->SetMoveSpeed(Infected->InvestigateSpeed);
		MoveToPoint(InvestigatePoint, 80.f);
		break;
	case EUSInfectedState::Chase:
		Infected->SetMoveSpeed(Infected->ChaseSpeed);
		break;
	case EUSInfectedState::Attack:
	case EUSInfectedState::Dead:
		break;
	}
}

void AUSInfectedAIController::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	UWorld* World = GetWorld();
	if (!World || !Infected || State == EUSInfectedState::Dead || Infected->IsDead())
	{
		return;
	}

	// Movimento direto de contingencia (sem NavMesh): aplicado a cada quadro.
	if (bDirectMoving)
	{
		const FVector ToDestination = DirectDestination - Infected->GetActorLocation();
		if (ToDestination.Size2D() <= DirectAcceptance)
		{
			bDirectMoving = false;
		}
		else
		{
			Infected->AddMovementInput(ToDestination.GetSafeNormal2D(), 1.f);
		}
	}

	if (TargetActor && !IsValidTarget(TargetActor))
	{
		TargetActor = nullptr; // alvo morreu ou sumiu
		EnterState(EUSInfectedState::Patrol);
		return;
	}

	const float Now = World->GetTimeSeconds();
	switch (State)
	{
	case EUSInfectedState::Patrol:      UpdatePatrol(Now); break;
	case EUSInfectedState::Investigate: UpdateInvestigate(Now, DeltaSeconds); break;
	case EUSInfectedState::Chase:       UpdateChase(Now); break;
	case EUSInfectedState::Attack:      UpdateAttack(Now); break;
	case EUSInfectedState::Dead:        break;
	}
}

void AUSInfectedAIController::UpdatePatrol(float Now)
{
	if (IsMovingToDestination())
	{
		return;
	}

	if (bPatrolMoving)
	{
		// Chegou (ou falhou): descansa um pouco antes do proximo ponto.
		bPatrolMoving = false;
		NextPatrolTime = Now + FMath::FRandRange(2.f, 5.f);
		return;
	}

	if (Now >= NextPatrolTime)
	{
		FVector Point;
		if (PickPatrolPoint(Point))
		{
			bPatrolMoving = true;
			MoveToPoint(Point, 80.f);
		}
		else
		{
			NextPatrolTime = Now + 2.f;
		}
	}
}

void AUSInfectedAIController::UpdateInvestigate(float Now, float DeltaSeconds)
{
	if (IsMovingToDestination())
	{
		return;
	}

	// Chegou ao ponto: olha ao redor por um tempo e volta a patrulhar.
	if (InvestigateUntil <= 0.f)
	{
		InvestigateUntil = Now + InvestigateDuration;
	}
	Infected->AddActorWorldRotation(FRotator(0.f, 70.f * DeltaSeconds, 0.f));

	if (Now >= InvestigateUntil)
	{
		EnterState(EUSInfectedState::Patrol);
	}
}

void AUSInfectedAIController::UpdateChase(float Now)
{
	if (!TargetActor)
	{
		EnterState(EUSInfectedState::Patrol);
		return;
	}

	const FVector TargetLocation = TargetActor->GetActorLocation();
	const float Distance = FVector::Dist2D(Infected->GetActorLocation(), TargetLocation);

	if (Distance <= Infected->AttackRange)
	{
		EnterState(EUSInfectedState::Attack);
		return;
	}

	if (Distance > LoseTargetDistance)
	{
		InvestigatePoint = TargetLocation;
		TargetActor = nullptr;
		EnterState(EUSInfectedState::Investigate);
		return;
	}

	if (Now >= NextRepathTime)
	{
		NextRepathTime = Now + 0.25f;
		MoveToPoint(TargetLocation, Infected->AttackRange * 0.6f);
	}
}

void AUSInfectedAIController::UpdateAttack(float Now)
{
	if (!TargetActor)
	{
		EnterState(EUSInfectedState::Patrol);
		return;
	}

	const FVector TargetLocation = TargetActor->GetActorLocation();
	const float Distance = FVector::Dist2D(Infected->GetActorLocation(), TargetLocation);

	if (Distance > Infected->AttackRange * 1.3f)
	{
		EnterState(EUSInfectedState::Chase);
		return;
	}

	FaceLocation(TargetLocation, GetWorld()->GetDeltaSeconds(), 540.f);

	if (Now >= NextAttackTime)
	{
		NextAttackTime = Now + FMath::Max(0.2f, Infected->AttackCooldown);
		Infected->PerformAttack(TargetActor);
	}
}

// ------------------------------------------------------------ movimento

void AUSInfectedAIController::MoveToPoint(const FVector& Destination, float AcceptanceRadius)
{
	const EPathFollowingRequestResult::Type Result = MoveToLocation(Destination, AcceptanceRadius, /*bStopOnOverlap*/ true, /*bUsePathfinding*/ true, /*bProjectDestinationToNavigation*/ true, /*bCanStrafe*/ false);

	if (Result == EPathFollowingRequestResult::Failed)
	{
		// Sem NavMesh (ou destino inalcancavel): anda em linha reta. Nao desvia de obstaculos.
		bDirectMoving = true;
		DirectDestination = Destination;
		DirectAcceptance = FMath::Max(AcceptanceRadius, 60.f);
	}
	else
	{
		bDirectMoving = false;
	}
}

void AUSInfectedAIController::StopAllMovement()
{
	StopMovement();
	bDirectMoving = false;
}

bool AUSInfectedAIController::IsMovingToDestination() const
{
	return bDirectMoving || GetMoveStatus() != EPathFollowingStatus::Idle;
}

bool AUSInfectedAIController::PickPatrolPoint(FVector& OutPoint) const
{
	UWorld* World = GetWorld();
	if (!World || !Infected)
	{
		return false;
	}

	if (UNavigationSystemV1* Nav = UNavigationSystemV1::GetCurrent(World))
	{
		FNavLocation Result;
		if (Nav->GetRandomReachablePointInRadius(HomeLocation, PatrolRadius, Result))
		{
			OutPoint = Result.Location;
			return true;
		}
	}

	// Fallback sem NavMesh: ponto aleatorio no plano, na altura atual.
	const FVector2D Offset = FMath::RandPointInCircle(PatrolRadius);
	OutPoint = FVector(HomeLocation.X + Offset.X, HomeLocation.Y + Offset.Y, Infected->GetActorLocation().Z);
	return true;
}

void AUSInfectedAIController::FaceLocation(const FVector& Location, float DeltaSeconds, float TurnSpeedDegPerSec) const
{
	const FVector ToTarget = Location - Infected->GetActorLocation();
	if (ToTarget.SizeSquared2D() < 1.f)
	{
		return;
	}
	const FRotator Wanted(0.f, ToTarget.Rotation().Yaw, 0.f);
	Infected->SetActorRotation(FMath::RInterpConstantTo(Infected->GetActorRotation(), Wanted, DeltaSeconds, TurnSpeedDegPerSec));
}
