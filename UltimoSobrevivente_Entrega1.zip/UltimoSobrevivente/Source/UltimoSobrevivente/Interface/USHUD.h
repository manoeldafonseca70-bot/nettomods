#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "USHUD.generated.h"

/**
 * HUD desenhado direto no Canvas: barra de vida, municao, mira, joystick e botoes touch.
 * Visual provisorio (aneis e retangulos). A interface final (UMG/Slate, arte propria, tela de
 * personalizacao dos controles) fica para uma etapa posterior.
 */
UCLASS()
class ULTIMOSOBREVIVENTE_API AUSHUD : public AHUD
{
	GENERATED_BODY()

public:
	virtual void DrawHUD() override;

private:
	void DrawCircle(const FVector2D& Center, float Radius, const FLinearColor& Color, float Thickness);
	void DrawTouchControls();
	void DrawSurvivalStatus();
};
