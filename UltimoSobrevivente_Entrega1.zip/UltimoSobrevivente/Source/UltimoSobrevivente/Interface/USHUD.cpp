#include "Interface/USHUD.h"
#include "Interface/USPlayerController.h"
#include "Personagens/USCharacter.h"
#include "Sobrevivencia/USHealthComponent.h"
#include "Armas/USWeaponComponent.h"
#include "UltimoSobrevivente.h"

#include "Engine/Canvas.h"

void AUSHUD::DrawHUD()
{
	Super::DrawHUD();
	if (!Canvas)
	{
		return;
	}

	DrawSurvivalStatus();
	DrawTouchControls();
}

void AUSHUD::DrawCircle(const FVector2D& Center, float Radius, const FLinearColor& Color, float Thickness)
{
	constexpr int32 Segments = 28;
	FVector2D Previous = Center + FVector2D(Radius, 0.0);
	for (int32 i = 1; i <= Segments; ++i)
	{
		const float Angle = 2.f * PI * static_cast<float>(i) / static_cast<float>(Segments);
		const FVector2D Next = Center + FVector2D(FMath::Cos(Angle), FMath::Sin(Angle)) * Radius;
		Canvas->K2_DrawLine(Previous, Next, Thickness, Color);
		Previous = Next;
	}
}

void AUSHUD::DrawSurvivalStatus()
{
	const AUSCharacter* Character = Cast<AUSCharacter>(GetOwningPawn());
	const float W = Canvas->SizeX;
	const float H = Canvas->SizeY;

	if (!Character)
	{
		// Sem pawn: provavelmente morto, aguardando reaparecer.
		const FString Msg = TEXT("VOCE MORREU - REAPARECENDO...");
		float TW = 0.f, TH = 0.f;
		GetTextSize(Msg, TW, TH, nullptr, 1.5f);
		DrawText(Msg, FLinearColor::Red, (W - TW) * 0.5f, H * 0.45f, nullptr, 1.5f);
		return;
	}

	// Barra de vida (canto superior esquerdo)
	if (const UUSHealthComponent* Health = Character->GetHealthComponent())
	{
		const float BarW = W * 0.22f, BarH = H * 0.03f, X = W * 0.03f, Y = H * 0.04f;
		const float Fraction = Health->GetHealthFraction();
		DrawRect(FLinearColor(0.f, 0.f, 0.f, 0.55f), X - 2.f, Y - 2.f, BarW + 4.f, BarH + 4.f);
		DrawRect(FLinearColor(0.8f * (1.f - Fraction) + 0.1f, 0.8f * Fraction, 0.1f, 0.9f), X, Y, BarW * Fraction, BarH);
		const FString HealthText = FString::Printf(TEXT("VIDA %d"), FMath::CeilToInt(Health->GetHealth()));
		DrawText(HealthText, FLinearColor::White, X, Y + BarH + 4.f, nullptr, 1.0f);
	}

	// Arma e municao (canto superior direito)
	if (const UUSWeaponComponent* Weapon = Character->GetWeaponComponent())
	{
		if (const FUSWeaponSlot* Slot = Weapon->GetCurrentSlot())
		{
			FString Line = Slot->Stats.DisplayName.ToString();
			if (Slot->Stats.Kind == EUSWeaponKind::Ranged)
			{
				Line += FString::Printf(TEXT("  %d / %d"), Slot->Magazine, Slot->Reserve);
				if (Weapon->IsReloading()) { Line += TEXT("  (RECARREGANDO)"); }
			}
			float TW = 0.f, TH = 0.f;
			GetTextSize(Line, TW, TH, nullptr, 1.2f);
			DrawText(Line, FLinearColor::White, W * 0.97f - TW, H * 0.04f, nullptr, 1.2f);
		}
	}

	// Mira no centro
	const FVector2D C(W * 0.5f, H * 0.5f);
	const FLinearColor CrossColor(1.f, 1.f, 1.f, 0.8f);
	Canvas->K2_DrawLine(C + FVector2D(-10.0, 0.0), C + FVector2D(-4.0, 0.0), 2.f, CrossColor);
	Canvas->K2_DrawLine(C + FVector2D(4.0, 0.0), C + FVector2D(10.0, 0.0), 2.f, CrossColor);
	Canvas->K2_DrawLine(C + FVector2D(0.0, -10.0), C + FVector2D(0.0, -4.0), 2.f, CrossColor);
	Canvas->K2_DrawLine(C + FVector2D(0.0, 4.0), C + FVector2D(0.0, 10.0), 2.f, CrossColor);
}

void AUSHUD::DrawTouchControls()
{
	const AUSPlayerController* PC = Cast<AUSPlayerController>(GetOwningPlayerController());
	if (!PC || !PC->AreTouchControlsEnabled())
	{
		return;
	}

	const float Alpha = FMath::Clamp(PC->ControlsOpacity, 0.1f, 1.f);

	TArray<FUSTouchButton> Buttons;
	PC->BuildTouchButtons(Buttons);
	for (const FUSTouchButton& B : Buttons)
	{
		const FLinearColor Color(1.f, B.bHeld ? 0.7f : 1.f, B.bHeld ? 0.2f : 1.f, Alpha * (B.bHeld ? 1.f : 0.85f));
		DrawCircle(B.Center, B.Radius, Color, B.bHeld ? 5.f : 3.f);
		if (B.bHeld)
		{
			DrawCircle(B.Center, B.Radius * 0.75f, Color, 3.f);
		}
		float TW = 0.f, TH = 0.f;
		GetTextSize(B.Label, TW, TH, nullptr, 0.8f);
		DrawText(B.Label, Color, B.Center.X - TW * 0.5f, B.Center.Y - TH * 0.5f, nullptr, 0.8f);
	}

	FVector2D Base, Knob;
	float Radius = 0.f;
	if (PC->GetJoystickVisual(Base, Knob, Radius))
	{
		const FLinearColor Color(1.f, 1.f, 1.f, Alpha);
		DrawCircle(Base, Radius, Color, 3.f);
		DrawCircle(Knob, Radius * 0.4f, Color, 6.f);
	}
}
