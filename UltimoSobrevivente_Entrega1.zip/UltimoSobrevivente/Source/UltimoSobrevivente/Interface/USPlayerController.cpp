#include "Interface/USPlayerController.h"
#include "Personagens/USCharacter.h"
#include "UltimoSobrevivente.h"

#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Components/InputComponent.h"

namespace
{
	uint32 ActionBit(EUSTouchAction Action) { return 1u << static_cast<uint32>(Action); }
}

AUSPlayerController::AUSPlayerController()
{
	bShowMouseCursor = false;
}

void AUSPlayerController::BeginPlay()
{
	Super::BeginPlay();

	// Touch ligado em Android/iOS, ou no PC com o argumento -ForceTouch (para depurar o layout).
#if PLATFORM_ANDROID || PLATFORM_IOS
	bTouchControlsEnabled = true;
#else
	bTouchControlsEnabled = FParse::Param(FCommandLine::Get(), TEXT("ForceTouch"));
#endif

	if (IsLocalController() && bTouchControlsEnabled)
	{
		// Remove os joysticks padrao da engine, que sobreporiam os nossos.
		ActivateTouchInterface(nullptr);
	}
}

void AUSPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();
	if (InputComponent)
	{
		InputComponent->BindTouch(IE_Pressed, this, &AUSPlayerController::TouchPressed);
		InputComponent->BindTouch(IE_Repeat, this, &AUSPlayerController::TouchMoved);
		InputComponent->BindTouch(IE_Released, this, &AUSPlayerController::TouchReleased);
	}
}

void AUSPlayerController::OnUnPossess()
{
	ReleaseAllTouch();
	Super::OnUnPossess();
}

AUSCharacter* AUSPlayerController::GetUSCharacter() const
{
	return Cast<AUSCharacter>(GetPawn());
}

FVector2D AUSPlayerController::GetViewportDims() const
{
	int32 X = 0, Y = 0;
	GetViewportSize(X, Y);
	return FVector2D(static_cast<double>(FMath::Max(X, 1)), static_cast<double>(FMath::Max(Y, 1)));
}

float AUSPlayerController::JoystickRadiusPx() const
{
	return GetViewportDims().Y * 0.12f * ControlsScale;
}

void AUSPlayerController::BuildTouchButtons(TArray<FUSTouchButton>& OutButtons) const
{
	OutButtons.Reset();
	const FVector2D V = GetViewportDims();
	const float Base = V.Y * 0.085f * ControlsScale;

	auto Add = [&](EUSTouchAction Action, const FVector2D& NormPos, float RadiusScale, const TCHAR* Label)
	{
		FUSTouchButton B;
		B.Action = Action;
		B.Center = FVector2D(NormPos.X * V.X, NormPos.Y * V.Y);
		B.Radius = Base * RadiusScale;
		B.Label = Label;
		B.bHeld = (HeldActionMask & ActionBit(Action)) != 0;
		OutButtons.Add(B);
	};

	Add(EUSTouchAction::Attack, AttackPos, 1.25f, TEXT("ATAQUE"));
	Add(EUSTouchAction::Jump, JumpPos, 1.0f, TEXT("PULAR"));
	Add(EUSTouchAction::Aim, AimPos, 1.0f, TEXT("MIRAR"));
	Add(EUSTouchAction::Sprint, SprintPos, 0.9f, TEXT("CORRER"));
	Add(EUSTouchAction::Crouch, CrouchPos, 0.9f, TEXT("AGACHAR"));
	Add(EUSTouchAction::Reload, ReloadPos, 0.8f, TEXT("RECARGA"));
	Add(EUSTouchAction::NextWeapon, WeaponPos, 0.7f, TEXT("ARMA"));
}

bool AUSPlayerController::GetJoystickVisual(FVector2D& OutBase, FVector2D& OutKnob, float& OutRadius) const
{
	if (JoystickFinger == INDEX_NONE || !Fingers[JoystickFinger].bActive)
	{
		return false;
	}
	const FFinger& F = Fingers[JoystickFinger];
	OutRadius = JoystickRadiusPx();
	OutBase = F.Start;
	const FVector2D Delta = (F.Last - F.Start).GetClampedToMaxSize(OutRadius);
	OutKnob = F.Start + Delta;
	return true;
}

// ------------------------------------------------------------ toques

void AUSPlayerController::TouchPressed(ETouchIndex::Type FingerIndex, FVector Location)
{
	const int32 Index = static_cast<int32>(FingerIndex);
	if (!bTouchControlsEnabled || Index < 0 || Index >= MaxFingers)
	{
		return;
	}

	FFinger& F = Fingers[Index];
	F = FFinger();
	F.bActive = true;
	const FVector2D P(Location.X, Location.Y);
	F.Start = F.Last = P;

	TArray<FUSTouchButton> Buttons;
	BuildTouchButtons(Buttons);
	for (const FUSTouchButton& B : Buttons)
	{
		if (FVector2D::DistSquared(P, B.Center) <= FMath::Square(B.Radius))
		{
			F.Role = EFingerRole::Button;
			F.Action = B.Action;
			ApplyAction(B.Action, true);
			return;
		}
	}

	if (P.X < GetViewportDims().X * 0.5 && JoystickFinger == INDEX_NONE)
	{
		F.Role = EFingerRole::Joystick;
		JoystickFinger = Index;
	}
	else
	{
		F.Role = EFingerRole::Look;
	}
}

void AUSPlayerController::TouchMoved(ETouchIndex::Type FingerIndex, FVector Location)
{
	const int32 Index = static_cast<int32>(FingerIndex);
	if (!bTouchControlsEnabled || Index < 0 || Index >= MaxFingers || !Fingers[Index].bActive)
	{
		return;
	}

	FFinger& F = Fingers[Index];
	const FVector2D P(Location.X, Location.Y);
	AUSCharacter* Character = GetUSCharacter();

	if (F.Role == EFingerRole::Joystick)
	{
		if (Character)
		{
			const FVector2D Delta = (P - F.Start) / FMath::Max(JoystickRadiusPx(), 1.f);
			// Tela: Y cresce para baixo; "frente" e para cima.
			Character->InputMoveTouch(FVector2D(Delta.X, -Delta.Y));
		}
	}
	else if (F.Role == EFingerRole::Look)
	{
		if (Character)
		{
			const FVector2D Delta = P - F.Last;
			Character->InputLookTouchPixels(static_cast<float>(Delta.X), static_cast<float>(Delta.Y));
		}
	}
	F.Last = P;
}

void AUSPlayerController::TouchReleased(ETouchIndex::Type FingerIndex, FVector Location)
{
	const int32 Index = static_cast<int32>(FingerIndex);
	if (Index < 0 || Index >= MaxFingers || !Fingers[Index].bActive)
	{
		return;
	}

	FFinger& F = Fingers[Index];
	if (F.Role == EFingerRole::Button)
	{
		ApplyAction(F.Action, false);
	}
	else if (F.Role == EFingerRole::Joystick)
	{
		JoystickFinger = INDEX_NONE;
		if (AUSCharacter* Character = GetUSCharacter())
		{
			Character->InputMoveTouch(FVector2D::ZeroVector);
		}
	}
	F = FFinger();
}

void AUSPlayerController::ApplyAction(EUSTouchAction Action, bool bPressed)
{
	if (bPressed) { HeldActionMask |= ActionBit(Action); } else { HeldActionMask &= ~ActionBit(Action); }

	AUSCharacter* Character = GetUSCharacter();
	if (!Character)
	{
		return;
	}

	switch (Action)
	{
	case EUSTouchAction::Jump:       Character->InputJump(bPressed); break;
	case EUSTouchAction::Sprint:     Character->InputSprint(bPressed); break;
	case EUSTouchAction::Attack:     Character->InputFire(bPressed); break;
	case EUSTouchAction::Aim:        Character->InputAim(bPressed); break;
	case EUSTouchAction::Crouch:     if (bPressed) { Character->InputCrouchToggle(); } break;
	case EUSTouchAction::Reload:     if (bPressed) { Character->InputReload(); } break;
	case EUSTouchAction::NextWeapon: if (bPressed) { Character->InputNextWeapon(); } break;
	default: break;
	}
}

void AUSPlayerController::ReleaseAllTouch()
{
	// Solta tudo que estava pressionado (perda de controle, morte, troca de pawn).
	if (AUSCharacter* Character = GetUSCharacter())
	{
		Character->InputMoveTouch(FVector2D::ZeroVector);
		Character->InputJump(false);
		Character->InputSprint(false);
		Character->InputFire(false);
		Character->InputAim(false);
	}
	for (FFinger& F : Fingers)
	{
		F = FFinger();
	}
	JoystickFinger = INDEX_NONE;
	HeldActionMask = 0;
}
