#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "USPlayerController.generated.h"

class AUSCharacter;

UENUM(BlueprintType)
enum class EUSTouchAction : uint8
{
	None,
	Jump,
	Crouch,
	Sprint,
	Attack,
	Aim,
	Reload,
	NextWeapon
};

/** Botao virtual calculado a partir do tamanho atual da tela (em pixels). */
struct FUSTouchButton
{
	EUSTouchAction Action = EUSTouchAction::None;
	FVector2D Center = FVector2D::ZeroVector;
	float Radius = 0.f;
	FString Label;
	bool bHeld = false;
};

/**
 * Controles touch desenhados e tratados em C++ (nao usa o Touch Interface da engine, que e asset binario).
 *
 *  - Joystick flutuante: surge onde o dedo toca na metade esquerda da tela; analogico de 0..1.
 *  - Metade direita fora dos botoes: arrastar gira a camera.
 *  - Botoes: ATAQUE, PULAR, AGACHAR, CORRER (segurar), MIRAR (segurar), RECARGAR, TROCAR ARMA.
 *
 * Tamanho, transparencia e posicao dos botoes sao configuraveis (UPROPERTY Config, salvos em
 * DefaultGame.ini / GameUserSettings futuramente). A tela de personalizacao ainda NAO existe.
 * Margens de seguranca (notch / cantos arredondados) ainda NAO tratadas.
 */
UCLASS(Config = Game)
class ULTIMOSOBREVIVENTE_API AUSPlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	AUSPlayerController();

	bool AreTouchControlsEnabled() const { return bTouchControlsEnabled; }

	/** Preenche os botoes para o tamanho de tela atual (usado tambem pelo HUD para desenhar). */
	void BuildTouchButtons(TArray<FUSTouchButton>& OutButtons) const;

	/** Dados do joystick para o HUD. Retorna false se nao ha dedo no joystick. */
	bool GetJoystickVisual(FVector2D& OutBase, FVector2D& OutKnob, float& OutRadius) const;

	UPROPERTY(Config, EditAnywhere, BlueprintReadWrite, Category = "US|Touch") float ControlsScale = 1.f;
	UPROPERTY(Config, EditAnywhere, BlueprintReadWrite, Category = "US|Touch") float ControlsOpacity = 0.6f;

	// Posicao dos botoes em fracao da tela (0..1). Valores iniciais provisorios, nao testados em aparelho.
	UPROPERTY(Config, EditAnywhere, Category = "US|Touch") FVector2D AttackPos = FVector2D(0.86f, 0.68f);
	UPROPERTY(Config, EditAnywhere, Category = "US|Touch") FVector2D JumpPos = FVector2D(0.94f, 0.46f);
	UPROPERTY(Config, EditAnywhere, Category = "US|Touch") FVector2D AimPos = FVector2D(0.73f, 0.80f);
	UPROPERTY(Config, EditAnywhere, Category = "US|Touch") FVector2D SprintPos = FVector2D(0.74f, 0.54f);
	UPROPERTY(Config, EditAnywhere, Category = "US|Touch") FVector2D CrouchPos = FVector2D(0.60f, 0.86f);
	UPROPERTY(Config, EditAnywhere, Category = "US|Touch") FVector2D ReloadPos = FVector2D(0.94f, 0.82f);
	UPROPERTY(Config, EditAnywhere, Category = "US|Touch") FVector2D WeaponPos = FVector2D(0.94f, 0.18f);

protected:
	virtual void BeginPlay() override;
	virtual void SetupInputComponent() override;
	virtual void OnUnPossess() override;

private:
	enum class EFingerRole : uint8 { None, Joystick, Look, Button };

	struct FFinger
	{
		bool bActive = false;
		EFingerRole Role = EFingerRole::None;
		EUSTouchAction Action = EUSTouchAction::None;
		FVector2D Start = FVector2D::ZeroVector;
		FVector2D Last = FVector2D::ZeroVector;
	};

	void TouchPressed(ETouchIndex::Type FingerIndex, FVector Location);
	void TouchMoved(ETouchIndex::Type FingerIndex, FVector Location);
	void TouchReleased(ETouchIndex::Type FingerIndex, FVector Location);

	void ApplyAction(EUSTouchAction Action, bool bPressed);
	void ReleaseAllTouch();
	FVector2D GetViewportDims() const;
	float JoystickRadiusPx() const;
	AUSCharacter* GetUSCharacter() const;

	static constexpr int32 MaxFingers = 10;
	FFinger Fingers[MaxFingers];
	int32 JoystickFinger = INDEX_NONE;
	uint32 HeldActionMask = 0;
	bool bTouchControlsEnabled = false;
};
