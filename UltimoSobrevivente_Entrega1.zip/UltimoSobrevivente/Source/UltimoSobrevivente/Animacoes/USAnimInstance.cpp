#include "Animacoes/USAnimInstance.h"
#include "Personagens/USCharacter.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"

void UUSAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

	const ACharacter* Character = Cast<ACharacter>(TryGetPawnOwner());
	if (!Character)
	{
		return;
	}

	const FVector Velocity = Character->GetVelocity();
	Speed = Velocity.Size2D();
	Direction = Speed > 1.f ? FMath::FindDeltaAngleDegrees(Character->GetActorRotation().Yaw, Velocity.Rotation().Yaw) : 0.f;
	bIsFalling = Character->GetCharacterMovement()->IsFalling();
	bIsCrouching = Character->bIsCrouched;

	if (const AUSCharacter* Player = Cast<AUSCharacter>(Character))
	{
		bIsAiming = Player->IsAiming();
		bIsSprinting = Player->IsSprinting();
	}
}
