#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "USAnimInstance.generated.h"

/**
 * Classe base nativa para o Animation Blueprint do personagem. Calcula as variaveis de locomocao
 * a cada quadro. O Animation Blueprint em si e um asset binario e precisa ser criado no editor:
 * crie um AnimBP com esta classe como Parent Class e monte a state machine usando estas variaveis.
 */
UCLASS()
class ULTIMOSOBREVIVENTE_API UUSAnimInstance : public UAnimInstance
{
	GENERATED_BODY()

public:
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;

	/** Velocidade horizontal em cm/s. */
	UPROPERTY(BlueprintReadOnly, Category = "US|Locomocao") float Speed = 0.f;
	/** Angulo (-180..180) entre a frente do personagem e a direcao do movimento. */
	UPROPERTY(BlueprintReadOnly, Category = "US|Locomocao") float Direction = 0.f;
	UPROPERTY(BlueprintReadOnly, Category = "US|Locomocao") bool bIsFalling = false;
	UPROPERTY(BlueprintReadOnly, Category = "US|Locomocao") bool bIsCrouching = false;
	UPROPERTY(BlueprintReadOnly, Category = "US|Locomocao") bool bIsAiming = false;
	UPROPERTY(BlueprintReadOnly, Category = "US|Locomocao") bool bIsSprinting = false;
};
