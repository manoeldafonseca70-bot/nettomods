#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "USHealthComponent.generated.h"

class UUSHealthComponent;
class AController;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FUSOnHealthChanged, UUSHealthComponent*, Component, float, NewHealth, float, Delta);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUSOnDeath, UUSHealthComponent*, Component, AController*, Killer);

/**
 * Vida e dano. Escuta OnTakeAnyDamage do dono, entao funciona com ApplyDamage / ApplyPointDamage
 * da engine. Usado pelo jogador e pelos inimigos. Somente a autoridade (servidor / single player)
 * processa dano, o que mantem o componente compativel com o multiplayer futuro.
 */
UCLASS(ClassGroup = (UltimoSobrevivente), meta = (BlueprintSpawnableComponent))
class ULTIMOSOBREVIVENTE_API UUSHealthComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UUSHealthComponent();

	UFUNCTION(BlueprintPure, Category = "US|Vida") float GetHealth() const { return Health; }
	UFUNCTION(BlueprintPure, Category = "US|Vida") float GetMaxHealth() const { return MaxHealth; }
	UFUNCTION(BlueprintPure, Category = "US|Vida") float GetHealthFraction() const { return MaxHealth > 0.f ? Health / MaxHealth : 0.f; }
	UFUNCTION(BlueprintPure, Category = "US|Vida") bool IsDead() const { return bDead; }

	UFUNCTION(BlueprintCallable, Category = "US|Vida") void Heal(float Amount);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "US|Vida", meta = (ClampMin = "1.0"))
	float MaxHealth = 100.f;

	UPROPERTY(BlueprintAssignable, Category = "US|Vida") FUSOnHealthChanged OnHealthChanged;
	UPROPERTY(BlueprintAssignable, Category = "US|Vida") FUSOnDeath OnDeath;

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void HandleAnyDamage(AActor* DamagedActor, float Damage, const UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser);

private:
	float Health = 0.f;
	bool bDead = false;
};
