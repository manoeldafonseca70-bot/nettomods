#include "Sobrevivencia/USHealthComponent.h"
#include "GameFramework/Actor.h"

UUSHealthComponent::UUSHealthComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UUSHealthComponent::BeginPlay()
{
	Super::BeginPlay();

	Health = MaxHealth;

	AActor* Owner = GetOwner();
	if (Owner && Owner->HasAuthority())
	{
		Owner->OnTakeAnyDamage.AddDynamic(this, &UUSHealthComponent::HandleAnyDamage);
	}
}

void UUSHealthComponent::HandleAnyDamage(AActor* DamagedActor, float Damage, const UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser)
{
	if (bDead || Damage <= 0.f)
	{
		return;
	}

	const float OldHealth = Health;
	Health = FMath::Clamp(Health - Damage, 0.f, MaxHealth);
	OnHealthChanged.Broadcast(this, Health, Health - OldHealth);

	if (Health <= 0.f)
	{
		bDead = true;
		OnDeath.Broadcast(this, InstigatedBy);
	}
}

void UUSHealthComponent::Heal(float Amount)
{
	if (bDead || Amount <= 0.f)
	{
		return;
	}

	const float OldHealth = Health;
	Health = FMath::Clamp(Health + Amount, 0.f, MaxHealth);
	if (Health != OldHealth)
	{
		OnHealthChanged.Broadcast(this, Health, Health - OldHealth);
	}
}
